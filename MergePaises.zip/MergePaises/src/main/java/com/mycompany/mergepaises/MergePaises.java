package com.mycompany.mergepaises;

public class MergePaises {

    public static void main(String[] args) {
        String[] veta = { "Angola", "Chile", "Grécia", "Itália", "Moçambique", "Portugal", "Rússia", "Suécia" };
        String[] vetb = { "Argentina", "Brasil", "Chile", "Dinamarca", "Espanha", "França", "Inglaterra", "Turquia", "Uruguai" };
        
        // A soma dos tamanhos dos vetores originais define o tamanho do vetor resultante
        String[] res = new String[veta.length + vetb.length];

        // Chamada do método de fusão
        mergePaises(veta, vetb, res);
        
        // Impressão do vetor resultante
        for (String pais : res) {
            System.out.println(pais);
        }
    }

    public static void mergePaises(String[] a, String[] b, String[] res) {
        int i = 0, j = 0, k = 0;

        // Enquanto houver elementos em ambos os vetores
        while (i < a.length && j < b.length) {
            // Comparar os elementos atuais de cada vetor e inserir o menor no vetor de resultado
            if (a[i].compareTo(b[j]) < 0) {
                res[k++] = a[i++];
            } else {
                res[k++] = b[j++];
            }
        }

        // Copiar os elementos restantes de cada vetor
        while (i < a.length) {
            res[k++] = a[i++];
        }

        while (j < b.length) {
            res[k++] = b[j++];
        }
    }
}

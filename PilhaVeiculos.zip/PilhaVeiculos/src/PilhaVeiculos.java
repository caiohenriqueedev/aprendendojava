import java.util.Stack;

public class PilhaVeiculos {
    private Stack<Veiculo> pilhaVeiculos;

    public PilhaVeiculos() {
        pilhaVeiculos = new Stack<>();
    }

    public void inserirVeiculo(Veiculo veiculo) {
        pilhaVeiculos.push(veiculo);
    }

    public Veiculo retirarVeiculo() {
        if (!pilhaVeiculos.isEmpty()) {
            return pilhaVeiculos.pop();
        } else {
            System.out.println("A pilha está vazia!");
            return null;
        }
    }

    public void mostrarVeiculos() {
        for (Veiculo veiculo : pilhaVeiculos) {
            System.out.println("Placa: " + veiculo.getPlaca());
            System.out.println("Marca: " + veiculo.getMarca());
            System.out.println("Modelo: " + veiculo.getModelo());
            System.out.println("Ano de Fabricação: " + veiculo.getAnoFabricacao());
            System.out.println("-----------------------------");
        }
    }
}

import java.util.LinkedList;
import java.util.Queue;
import javax.swing.JOptionPane;

public class FilaFilmes {
    private Queue<Filme> filmes;

    public FilaFilmes() {
        filmes = new LinkedList<>();
    }

    public void adicionarFilme(Filme filme) {
        filmes.add(filme);
    }

    public void eliminarFilmesAcao() {
        while (!filmes.isEmpty()) {
            Filme filme = filmes.peek();
            if (filme.getGenero().equalsIgnoreCase("ação")) {
                System.out.println("Primeiro filme de ação encontrado:");
                exibirFilme(filme);
                break;
            } else {
                System.out.println("Removendo filme não de ação:");
                exibirFilme(filmes.poll());
            }
        }
    }

    private void exibirFilme(Filme filme) {
        System.out.println("Título: " + filme.getTitulo());
        System.out.println("Diretor: " + filme.getDiretor());
        System.out.println("Gênero: " + filme.getGenero());
        System.out.println("País: " + filme.getPais());
        System.out.println("Ano: " + filme.getAno());
        System.out.println();
    }

    // Método para adicionar filmes na fila a partir da interface gráfica
    public void adicionarFilmeGUI(Filme filme) {
        filmes.add(filme);
        JOptionPane.showMessageDialog(null, "Filme adicionado com sucesso!");
    }
}

public class OrdenacaoTrabalhadores {

    public static void main(String[] args) {
        Trabalhador[] trabalhadores = {
            new Trabalhador("Joao", 2000),
            new Trabalhador("Maria", 1500),
            new Trabalhador("Pedro", 2500),
            new Trabalhador("Ana", 1800)
        };

        // Ordenação por salário decrescente
        quickSortSalarioDecrescente(trabalhadores, 0, trabalhadores.length - 1);
        System.out.println("Ordenação por salário decrescente:");
        for (Trabalhador t : trabalhadores) {
            System.out.println(t.getNome() + ": " + t.getSalario());
        }

        // Ordenação por nome crescente
        quickSortNomeCrescente(trabalhadores, 0, trabalhadores.length - 1);
        System.out.println("\nOrdenação por nome crescente:");
        for (Trabalhador t : trabalhadores) {
            System.out.println(t.getNome() + ": " + t.getSalario());
        }
    }

    public static void quickSortSalarioDecrescente(Trabalhador[] vetor, int inicio, int fim) {
        if (vetor == null || vetor.length == 0 || inicio >= fim) return;

        int posicaoPivo = separarSalario(vetor, inicio, fim);

        quickSortSalarioDecrescente(vetor, inicio, posicaoPivo - 1);
        quickSortSalarioDecrescente(vetor, posicaoPivo + 1, fim);
    }

    private static int separarSalario(Trabalhador[] vetor, int inicio, int fim) {
        Trabalhador pivo = vetor[inicio];
        int i = inicio + 1, f = fim;
        while (i <= f) {
            if (vetor[i].getSalario() > pivo.getSalario()) {
                i++;
            } else if (pivo.getSalario() > vetor[f].getSalario()) {
                f--;
            } else {
                Trabalhador troca = vetor[i];
                vetor[i] = vetor[f];
                vetor[f] = troca;
                i++;
                f--;
            }
        }
        vetor[inicio] = vetor[f];
        vetor[f] = pivo;
        return f;
    }

    public static void quickSortNomeCrescente(Trabalhador[] vetor, int inicio, int fim) {
        if (vetor == null || vetor.length == 0 || inicio >= fim) return;

        int posicaoPivo = separarNome(vetor, inicio, fim);

        quickSortNomeCrescente(vetor, inicio, posicaoPivo - 1);
        quickSortNomeCrescente(vetor, posicaoPivo + 1, fim);
    }

    private static int separarNome(Trabalhador[] vetor, int inicio, int fim) {
        Trabalhador pivo = vetor[inicio];
        int i = inicio + 1, f = fim;
        while (i <= f) {
            if (vetor[i].getNome().compareToIgnoreCase(pivo.getNome()) <= 0) {
                i++;
            } else if (pivo.getNome().compareToIgnoreCase(vetor[f].getNome()) < 0) {
                f--;
            } else {
                Trabalhador troca = vetor[i];
                vetor[i] = vetor[f];
                vetor[f] = troca;
                i++;
                f--;
            }
        }
        vetor[inicio] = vetor[f];
        vetor[f] = pivo;
        return f;
    }
}

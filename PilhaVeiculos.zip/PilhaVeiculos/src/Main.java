public class Main {
    public static void main(String[] args) {
        PilhaVeiculos pilha = new PilhaVeiculos();

        // Criando alguns veículos
        Veiculo veiculo1 = new Veiculo("ABC1234", "Ford", "Focus", 2019);
        Veiculo veiculo2 = new Veiculo("DEF5678", "Toyota", "Corolla", 2020);
        Veiculo veiculo3 = new Veiculo("GHI9101", "Honda", "Civic", 2018);

        // Inserindo os veículos na pilha
        pilha.inserirVeiculo(veiculo1);
        pilha.inserirVeiculo(veiculo2);
        pilha.inserirVeiculo(veiculo3);

        // Mostrando os veículos da pilha
        pilha.mostrarVeiculos();

        // Retirando um veículo da pilha e mostrando seus dados
        System.out.println("Veículo retirado da pilha:");
        Veiculo veiculoRetirado = pilha.retirarVeiculo();
        if (veiculoRetirado != null) {
            System.out.println("Placa: " + veiculoRetirado.getPlaca());
            System.out.println("Marca: " + veiculoRetirado.getMarca());
            System.out.println("Modelo: " + veiculoRetirado.getModelo());
            System.out.println("Ano de Fabricação: " + veiculoRetirado.getAnoFabricacao());
        }
    }
}
